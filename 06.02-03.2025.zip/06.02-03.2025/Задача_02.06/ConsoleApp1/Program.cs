﻿public class Program
{
    private static void Main(string[] args)
    {

        List<string> results = new List<string>();

        string line;
        while ((line = Console.ReadLine()) != "END")
        {
            string[] parts = line.Split(' ');

            if (parts[0] == "ST")
            {
                string name = parts[1];
                string date = parts[2];
                string bulstat = parts[3];
                string owner = parts[4] + " " + parts[5];
                double initialCapital = double.Parse(parts[6]);
                double actualCapital = double.Parse(parts[7]);

                double tax = 0.15 * (actualCapital - initialCapital);
                results.Add($"{bulstat} {name} {tax:F2} lv.");
            }
            else if (parts[0] == "LC")
            {
                string name = parts[1];
                string date = parts[2];
                string bulstat = parts[3];
                string article = parts[4];
                double actualCapital = double.Parse(parts[5]);

                double initialCapital = 17580.0;
                double tax = 0.10 * (actualCapital - initialCapital);
                results.Add($"{bulstat} {name} {tax:F2} lv.");
            }
        }

        foreach (var result in results)
        {
            Console.WriteLine(result);
        }
    }
}