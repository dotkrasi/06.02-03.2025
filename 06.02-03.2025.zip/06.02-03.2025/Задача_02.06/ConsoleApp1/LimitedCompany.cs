﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net.WebSockets;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class LimitedCompany : Company
    {
        private string articleOfAssociationNumber;

        public string ArticleOfAssociationNumber
        {
            get { return articleOfAssociationNumber; }
            set { articleOfAssociationNumber = value; }
        }

        private double actualCapital;


        public double ActualCapital
        {
            get { return actualCapital; }
            set { actualCapital = value; }
        }
        private double initialCapital;

        public double InitialCapital
        {
            get { return initialCapital; }
            set { initialCapital = value; }
        }



        public LimitedCompany(string articleOfAssiciationNumber, double actualCapital, double initialCapital, string companyName, string date, string bulstat) : base(companyName, date, bulstat)
        {

            this.ArticleOfAssociationNumber = articleOfAssiciationNumber;
            this.ActualCapital = actualCapital;
            this.InitialCapital = initialCapital;
            this.CompanyName = companyName;
            this.Date = date;
            this.Bulstat = bulstat;
        }

        public void LimitedCompanyTax()
        {

            double profit = ActualCapital - InitialCapital;
            double tax = 0.10 * profit;
            Console.WriteLine($"The income tax is: {tax}");

        }
    }
}
