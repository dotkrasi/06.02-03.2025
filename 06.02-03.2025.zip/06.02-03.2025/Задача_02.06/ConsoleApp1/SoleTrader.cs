﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Transactions;
using System.Xml.Linq;
using static System.Runtime.InteropServices.JavaScript.JSType;

namespace ConsoleApp1
{
    public class SoleTrader : Company
    {

        private string name;

        public string Name
        {
            get { return name; }
            set { name = value; }
        }

        private double initialCaptial;

        public double InitialCapital
        {
            get { return initialCaptial; }
            set { initialCaptial = value; }
        }

        private double actualCapital;

        public double ActualCapital
        {
            get { return actualCapital; }
            set { actualCapital = value; }
        }

        public void Tax()
        {
            double diff = ActualCapital - InitialCapital;
            double tax = 0.15 * diff;
            Console.WriteLine($"The tax is: {tax}");
        }

        public SoleTrader(string name, double intialCapital, double actualCapital,string companyName, string date,string bulstat) : base(companyName, date, bulstat)
        {
            this.Name = name;
            this.InitialCapital = intialCapital;
            this.ActualCapital = actualCapital;
            this.CompanyName = companyName;
            this.Date = date;
            this.Bulstat = bulstat;
        }
    }
}
