﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    public class Company
    {

        private string companyName;

        public string CompanyName
        {
            get { return companyName; }
            set { companyName = value; }
        }

        private string date;

        public string Date
        {
            get { return date; }
            set
            {
                if (value == string.Empty)
                {
                    throw new ArgumentException("Date cannot be empty");
                }
                date = value;
            }
        }

        private string bulstat;

        public string Bulstat
        {
            get { return Bulstat; }
            set
            {
                if (value.Length != 10)
                {
                    throw new ArgumentException("Bulstat must be exactly 10 characters");
                }

                Bulstat = value;
            }
        }

        public Company(string companyName, string date, string bulstat)
        {
            this.companyName = companyName;
            this.Date = date;
            this.Bulstat = bulstat;
        }


    }
}
