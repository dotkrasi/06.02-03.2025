using System.Windows.Forms;

namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {

        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string name = textBox1.Text;
            string date = textBox2.Text;
            string bulstat = textBox3.Text;
            string ownerOrNumber = textBox4.Text;
            double initialCapital = double.Parse(textBox5.Text);
            double actualCapital = double.Parse(textBox6.Text);

            double profit = actualCapital - initialCapital;
            double tax = 0;

            if (radioButton1.Checked)
            {
                tax = 0.15 * profit;
            }
            else if (radioButton2.Checked)
            {
                tax = 0.10 * profit;
            }


            double netProfit = profit - tax;

            string result = $"{bulstat} {name} {netProfit} lv.";
            listBox1.Items.Add(result);
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }
    }
}
