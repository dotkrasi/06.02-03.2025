using System.Diagnostics;

namespace WinFormsApp2
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            double money = double.Parse(textBox1.Text);
            char gender = char.Parse(textBox2.Text);
            int age = int.Parse(textBox3.Text);
            string sport = textBox4.Text;


            double price = 0;

            if (gender == 'm')
            {
                switch (sport)
                {
                    case "Gym": price = 42; break;
                    case "Boxing": price = 41; break;
                    case "Yoga": price = 45; break;
                    case "Zumba": price = 34; break;
                    case "Dances": price = 51; break;
                    case "Pilates": price = 39; break;
                }
            }
            else if (gender == 'f')
            {
                switch (sport)
                {
                    case "Gym": price = 35; break;
                    case "Boxing": price = 37; break;
                    case "Yoga": price = 42; break;
                    case "Zumba": price = 31; break;
                    case "Dances": price = 53; break;
                    case "Pilates": price = 37; break;
                }
                string result = $"";
            }
            if (age <= 19)
            {
                price *= 0.8; 
            }

            if (money >= price)
            {
                string result = $"You purchased a 1 month pass for {sport}.";
                listBox1.Items.Add(result);
            }
            else
            {
                double needed = price - money;
                listBox1.Items.Add($"You don't have enough money! You need ${needed:F2} more.");
            }

            
        }
    }
}
