﻿using System;

class Program
{
    static void Main()
    {
        int n = int.Parse(Console.ReadLine());

        int hearthstone = 0;
        int fortnite = 0;
        int overwatch = 0;
        int others = 0;

        for (int i = 0; i < n; i++)
        {
            string game = Console.ReadLine();

            switch (game)
            {
                case "Hearthstone":
                    hearthstone++;
                    break;
                case "Fortnite":
                    fortnite++;
                    break;
                case "Overwatch":
                    overwatch++;
                    break;
                default:
                    others++;
                    break;
            }
        }

        Console.WriteLine($"Hearthstone - {((double)hearthstone / n * 100):F2}%");
        Console.WriteLine($"Fortnite - {((double)fortnite / n * 100):F2}%");
        Console.WriteLine($"Overwatch - {((double)overwatch / n * 100):F2}%");
        Console.WriteLine($"Others - {((double)others / n * 100):F2}%");
    }
}
