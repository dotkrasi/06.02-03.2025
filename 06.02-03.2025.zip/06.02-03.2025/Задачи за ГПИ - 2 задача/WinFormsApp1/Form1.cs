namespace WinFormsApp1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string[] games = new string[]
            {
        textBox1.Text.Trim(),
        textBox2.Text.Trim(),
        textBox3.Text.Trim(),
        textBox4.Text.Trim(),
        textBox5.Text.Trim()
            };

            int n = games.Length;

            int hearthstone = 0;
            int fortnite = 0;
            int overwatch = 0;
            int others = 0;

            foreach (string game in games)
            {
                switch (game)
                {
                    case "Hearthstone":
                        hearthstone++;
                        break;
                    case "Fortnite":
                        fortnite++;
                        break;
                    case "Overwatch":
                        overwatch++;
                        break;
                    default:
                        others++;
                        break;
                }
            }

            listBox1.Items.Clear();

            listBox1.Items.Add($"Hearthstone - {((double)hearthstone / n * 100):F2}%");
            listBox1.Items.Add($"Fortnite - {((double)fortnite / n * 100):F2}%");
            listBox1.Items.Add($"Overwatch - {((double)overwatch / n * 100):F2}%");
            listBox1.Items.Add($"Others - {((double)others / n * 100):F2}%");
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }
    }

}


